<?php
ob_clean();
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/../../app/models/Sala.php';

$model = new Sala();
$salas = $model->getAll();

echo json_encode($salas);
exit;