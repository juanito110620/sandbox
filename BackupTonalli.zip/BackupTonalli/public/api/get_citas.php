<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../app/config/database.php';

// leer datos JSON de entrada
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['idUsuario'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Falta idUsuario'
    ]);
    exit;
}

$idUsuario = intval($data['idUsuario']);

$sql = "SELECT id_cita, fecha, hora, nombre_visitante, telefono, correo, cantidad_personas, observaciones 
        FROM citas 
        WHERE id_usuario = ?
        ORDER BY fecha DESC";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

$citas = [];
while ($row = $result->fetch_assoc()) {
    $citas[] = $row;
}

echo json_encode([
    'status' => 'ok',
    'citas' => $citas
]);
?>