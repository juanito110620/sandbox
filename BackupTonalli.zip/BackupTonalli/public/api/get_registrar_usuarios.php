<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../app/config/database.php';

// Recibir datos en JSON
$input = json_decode(file_get_contents('php://input'), true);

$firebase_uid = $input['firebase_uid'] ?? '';
$nombre = $input['nombre'] ?? '';
$correo = $input['correo'] ?? '';

if (empty($firebase_uid) || empty($correo)) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos']);
    exit;
}

// Buscar usuario por firebase_uid o correo
$stmt = $conexion->prepare("SELECT id_usuario FROM usuarios WHERE firebase_uid = ? OR correo = ?");
$stmt->bind_param('ss', $firebase_uid, $correo);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    // Usuario existente: obtener su id
    $stmt->bind_result($idUsuarioExistente);
    $stmt->fetch();

    // Opcional: actualizar nombre
    $update = $conexion->prepare("UPDATE usuarios SET nombre = ? WHERE id_usuario = ?");
    $update->bind_param('si', $nombre, $idUsuarioExistente);
    $update->execute();

    echo json_encode([
        'status' => 'ok',
        'message' => 'Usuario ya existente, datos actualizados',
        'id_usuario' => $idUsuarioExistente
    ]);
} else {
    // Insertar nuevo usuario
    $insert = $conexion->prepare("INSERT INTO usuarios (firebase_uid, nombre, correo) VALUES (?,?,?)");
    $insert->bind_param('sss', $firebase_uid, $nombre, $correo);

    if ($insert->execute()) {
        $nuevoId = $insert->insert_id;
        echo json_encode([
            'status' => 'ok',
            'message' => 'Usuario registrado correctamente',
            'id_usuario' => $nuevoId
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Error al registrar usuario: ' . $conexion->error
        ]);
    }
}