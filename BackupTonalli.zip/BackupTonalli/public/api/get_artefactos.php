<?php
ob_clean();
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . '/../../app/models/Artefacto.php';

$model = new Artefacto();
$artefactos = $model->getAll();

echo json_encode($artefactos);
exit;