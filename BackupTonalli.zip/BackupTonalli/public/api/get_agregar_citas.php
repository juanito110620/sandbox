<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../app/config/database.php';

// Si entras por navegador (GET), devuelve un aviso
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(['success' => false, 'message' => 'Usa método POST para registrar una cita']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Datos no recibidos']);
    exit;
}

$id_usuario = intval($data['idUsuario']);
$fecha = $conexion->real_escape_string($data['fecha']);
$hora = isset($data['hora']) ? $conexion->real_escape_string($data['hora']) : null;
$nombre_visitante = $conexion->real_escape_string($data['nombreVisitante']);
$telefono = $conexion->real_escape_string($data['telefono']);
$correo = $conexion->real_escape_string($data['correo']);
$cantidad = intval($data['cantidadPersonas']);
$observaciones = $conexion->real_escape_string($data['observaciones']);

$sql = "INSERT INTO citas (id_usuario, fecha, hora, nombre_visitante, telefono, correo, cantidad_personas, observaciones)
        VALUES ('$id_usuario', '$fecha', " . ($hora ? "'$hora'" : "NULL") . ", '$nombre_visitante', '$telefono', '$correo', '$cantidad', '$observaciones')";

if ($conexion->query($sql)) {
    echo json_encode(['success' => true, 'message' => 'Cita registrada correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al registrar cita: ' . $conexion->error]);
}

$conexion->close();