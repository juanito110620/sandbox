<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../app/config/database.php';

// leer datos JSON de entrada
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['id_cita']) || !isset($data['id_usuario'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Faltan parámetros'
    ]);
    exit;
}

$idCita = intval($data['id_cita']);
$idUsuario = intval($data['id_usuario']);

// Elimina la cita sólo si pertenece a ese usuario
$sql = "DELETE FROM citas WHERE id_cita = ? AND id_usuario = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ii", $idCita, $idUsuario);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode([
            'status' => 'ok',
            'message' => 'Cita cancelada correctamente'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'No se encontró la cita o no pertenece a este usuario'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Error al ejecutar la consulta'
    ]);
}
?>