<?php
if (!isset($_SESSION['admin_nombre'])) {
    header("Location: index.php?url=login");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Citas - TonalliApp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="public/css/styles.css" />
</head>

<body>
    <header class="main-header d-flex align-items-center px-4 shadow-sm">
        <img src="public/img/logo.png" alt="Logo TonalliApp" class="logo">
        <h1 class="app-title">TonalliApp</h1>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-4 col-lg-3 d-md-block bg-light sidebar border-end vh-100">
                <div class="position-sticky pt-3">
                    <h4 class="text-center py-3 text-primary">Menú</h4>
                    <ul class="nav flex-column px-3">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=dashboard"><i class="fas fa-home me-2"></i>Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=salas"><i class="fas fa-door-open me-2"></i>Salas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=artefactos"><i class="fas fa-landmark me-2"></i>Artefactos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=autores"><i class="fas fa-user-edit me-2"></i>Autores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=citas"><i class="fas fa-calendar-check me-2"></i>Citas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=usuarios"><i class="fas fa-users me-2"></i>Usuarios</a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="index.php?url=login"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="col-md-8 ms-sm-auto col-lg-9 px-md-4 pt-4">
                <h2 class="tonalli-header mb-4">Gestión de Citas</h2>

                <!-- Barra de búsqueda -->
                <form class="row g-3 mb-4" method="get">
                    <input type="hidden" name="url" value="citas">
                    <div class="col-md-6">
                        <input type="text" name="busqueda" class="form-control" placeholder="Buscar por ID de usuario o nombre de visitante">
                    </div>
                    <div class="col-md-2">
                        <button class="btn w-100" type="submit"><i class="fas fa-search me-2"></i>Buscar</button>
                    </div>
                    <div class="col-md-2">
                        <a href="index.php?url=citas" class="btn btn-secondary w-100">Limpiar</a>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Visitante</th>
                                <th>Teléfono</th>
                                <th>Correo</th>
                                <th>Personas</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Observaciones</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($citas)): ?>
                                <?php foreach ($citas as $c): ?>
                                    <tr>
                                        <td><?= $c['id_cita'] ?></td>
                                        <td><?= htmlspecialchars($c['nombre_usuario']) ?></td>
                                        <td><?= htmlspecialchars($c['nombre_visitante']) ?></td>
                                        <td><?= htmlspecialchars($c['telefono']) ?></td>
                                        <td><?= htmlspecialchars($c['correo']) ?></td>
                                        <td><?= $c['cantidad_personas'] ?></td>
                                        <td><?= $c['fecha'] ?></td>
                                        <td><?= $c['hora'] ?></td>
                                        <td><?= htmlspecialchars($c['observaciones']) ?></td>
                                        <td class="text-end">
                                            <button class="btn btn-danger btn-sm" onclick="eliminarCita(<?= $c['id_cita'] ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="text-center text-muted">No se encontraron resultados</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© <?= date("Y"); ?> SANDBOX. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script>
        function eliminarCita(id) {
            if (confirm('¿Eliminar esta cita?')) {
                fetch('?url=citas/delete', {
                        method: 'POST',
                        body: new URLSearchParams({
                            id_cita: id
                        })
                    })
                    .then(r => r.json())
                    .then(j => {
                        if (j.status === 'ok') location.reload();
                        else alert('Error al eliminar');
                    });
            }
        }
    </script>
</body>

</html>