<?php
if (!isset($_SESSION['admin_nombre'])) {
    header("Location: index.php?url=login");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Panel de Administración - TonalliApp</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap 5 y Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="public/css/styles.css" />
</head>

<body>

    <!-- HEADER -->
    <header class="main-header px-4 d-flex justify-content-between align-items-center">
        <img src="public/img/logo.png" alt="Logo TonalliApp" class="logo">
        <h1 class="app-title m-0">TonalliApp - Administración</h1>
    </header>

    <div class="container-fluid">
        <div class="row">

            <!-- SIDEBAR -->
            <nav class="col-md-4 col-lg-3 sidebar d-md-block bg-light border-end">
                <div class="position-sticky pt-4">
                    <h4 class="text-center text-primary mb-4">Menú</h4>
                    <ul class="nav flex-column px-3">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=dashboard"><i class="fas fa-home me-2"></i>Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=salas"><i class="fas fa-door-open me-2"></i>Salas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=artefactos"><i class="fas fa-landmark me-2"></i>Artefactos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=autores"><i class="fas fa-user-edit me-2"></i>Autores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=citas"><i class="fas fa-calendar-check me-2"></i>Citas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=usuarios"><i class="fas fa-users me-2"></i>Usuarios</a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="index.php?url=login"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- MAIN -->
            <main class="col-md-8 ms-sm-auto col-lg-9 px-md-5 pt-5">
                <h2 class="tonalli-header text-center mb-5">Bienvenido, <?php echo htmlspecialchars($_SESSION['admin_nombre']); ?></h2>

                <div class="card dashboard-card shadow-sm p-4 text-center">
                    <h5 class="text-primary mb-2">Total Salas</h5>
                    <p class="display-5 fw-bold"><?php echo $totalSalas; ?></p>
                </div>

                <div class="card dashboard-card shadow-sm p-4 text-center">
                    <h5 class="text-primary mb-2">Artefactos</h5>
                    <p class="display-5 fw-bold"><?php echo $totalArtefactos; ?></p>
                </div>

                <div class="card dashboard-card shadow-sm p-4 text-center">
                    <h5 class="text-primary mb-2">Citas Pendientes</h5>
                    <p class="display-5 fw-bold"><?php echo $totalCitas; ?></p>
                </div>

                <!-- FOOTER -->
                <footer class="footer">
                    <div class="container text-center">
                        <p class="mb-0">© <?php echo date("Y"); ?> SANDBOX. Todos los derechos reservados.</p>
                    </div>
                </footer>

</body>

</html>