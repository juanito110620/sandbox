<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - TonalliApp</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="public/css/styles.css" />
</head>

<body class="bg-light">

    <div class="container-fluid vh-100">
        <div class="row h-100">

            <!-- Imagen -->
            <!-- Imagen -->
            <div class="col-md-6 d-none d-md-block p-0">
                <img src="public/img/museo-login.png" alt="Museo" class="img-fluid h-100 w-100 object-fit-cover">
            </div>

            <!-- Formulario -->
            <div class="col-md-6 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75 fade-in">

                    <h2 class="text-center tonalli-header mb-4">TonalliApp</h2>

                    <?php if (isset($_GET['error'])): ?>
                        <div class="alert alert-danger text-center">Credenciales incorrectas</div>
                    <?php endif; ?>

                    <form method="POST" action="index.php?url=authenticate">
                        <div class="mb-3">
                            <label for="usuario" class="form-label">Correo</label>
                            <input type="email" class="form-control" id="usuario" name="usuario" required placeholder="admin@tonalli.com">
                        </div>

                        <div class="mb-3">
                            <label for="contrasena" class="form-label">Contraseña</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="contrasena" name="contrasena" required placeholder="••••••••">
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                    <i class="fa-solid fa-eye" id="eyeIcon"></i>
                                </button>
                            </div>
                        </div>

                        <button type="submit" class="btn login-btn w-100 mt-3">Iniciar sesión</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- Mostrar/Ocultar contraseña -->
    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('contrasena');
        const eyeIcon = document.getElementById('eyeIcon');

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            eyeIcon.classList.toggle('fa-eye');
            eyeIcon.classList.toggle('fa-eye-slash');
        });
    </script>

</body>

</html>