<?php
if (!isset($_SESSION['admin_nombre'])) {
    header("Location: index.php?url=login");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Artefactos - TonalliApp</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="public/css/styles.css" />
</head>

<body>
    <header class="main-header d-flex align-items-center px-4 shadow-sm">
        <img src="public/img/logo.png" alt="Logo TonalliApp" class="logo">
        <h1 class="app-title">TonalliApp</h1>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-4 col-lg-3 d-md-block bg-light sidebar border-end vh-100">
                <div class="position-sticky pt-3">
                    <h4 class="text-center py-3 text-primary">Menú</h4>
                    <ul class="nav flex-column px-3">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=dashboard"><i class="fas fa-home me-2"></i>Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=salas"><i class="fas fa-door-open me-2"></i>Salas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=artefactos"><i class="fas fa-landmark me-2"></i>Artefactos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=autores"><i class="fas fa-user-edit me-2"></i>Autores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=citas"><i class="fas fa-calendar-check me-2"></i>Citas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=usuarios"><i class="fas fa-users me-2"></i>Usuarios</a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="index.php?url=login"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="col-md-8 ms-sm-auto col-lg-9 px-md-4 pt-4">
                <h2 class="tonalli-header mb-4">Gestión de Artefactos</h2>

                <form id="formArtefacto" class="row g-3 mb-4" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id_artefacto" id="id_artefacto">

                    <div class="col-md-4">
                        <input name="nombre" id="nombre" class="form-control" placeholder="Nombre del artefacto" required />
                    </div>

                    <div class="col-md-4">
                        <input name="descripcion" id="descripcion" class="form-control" placeholder="Descripción" required />
                    </div>

                    <div class="col-md-4">
                        <input type="file" name="imagen" id="imagen" class="form-control" accept="image/*" required />
                        <img id="previewImagen" src="" alt="Vista previa" style="max-height: 100px; margin-top: 5px; display:none;" />
                    </div>

                    <div class="col-md-4">
                        <select name="id_sala" id="id_sala" class="form-select" required>
                            <option value="">Seleccionar Sala</option>
                            <?php foreach ($salas as $s): ?>
                                <option value="<?= $s['id_sala'] ?>"><?= htmlspecialchars($s['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <select name="id_tipo" id="id_tipo" class="form-select" required>
                            <option value="">Seleccionar Tipo</option>
                            <?php foreach ($tipos as $t): ?>
                                <option value="<?= $t['id_tipo'] ?>"><?= htmlspecialchars($t['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <select name="id_autor" id="id_autor" class="form-select" required>
                            <option value="">Seleccionar Autor</option>
                            <?php foreach ($autores as $a): ?>
                                <option value="<?= $a['id_autor'] ?>"><?= htmlspecialchars($a['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <input name="fecha_creacion" id="fecha_creacion" type="date" class="form-control" />
                    </div>

                    <div class="col-md-4">
                        <button type="submit" class="btn w-100 btn-primary">Guardar</button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Imagen</th>
                                <th>Sala</th>
                                <th>Tipo</th>
                                <th>Autor</th>
                                <th>Fecha</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $currentSala = null;
                            $contador = 1;
                            foreach ($artefactos as $a):
                                if ($currentSala !== $a['nombre_sala']):
                                    $currentSala = $a['nombre_sala'];
                            ?>
                                    <tr class="table-primary">
                                        <td colspan="9" class="fw-bold"><?= htmlspecialchars($currentSala) ?></td>
                                    </tr>
                                <?php endif; ?>
                                <tr>
                                    <td><?= $contador++ ?></td> <!-- Número visual continuo -->
                                    <td><?= htmlspecialchars($a['nombre']) ?></td>
                                    <td><?= htmlspecialchars($a['descripcion']) ?></td>
                                    <td><img src="<?= htmlspecialchars($a['imagen']) ?>" alt="Imagen" width="60" height="60" style="object-fit:cover; border-radius:8px;"></td>
                                    <td><?= htmlspecialchars($a['nombre_sala']) ?></td>
                                    <td><?= htmlspecialchars($a['nombre_tipo']) ?></td>
                                    <td><?= htmlspecialchars($a['nombre_autor']) ?></td>
                                    <td><?= $a['fecha_creacion'] ?></td>
                                    <td class="text-end">
                                        <button class="btn-icon edit" onclick="editarArtefacto(<?= $a['id_artefacto'] ?>, '<?= htmlspecialchars($a['nombre']) ?>', '<?= htmlspecialchars($a['descripcion']) ?>', '<?= htmlspecialchars($a['imagen']) ?>', <?= $a['id_sala'] ?>, <?= $a['id_tipo'] ?>, <?= $a['id_autor'] ?>, '<?= $a['fecha_creacion'] ?>')"><i class="fas fa-pen"></i></button>
                                        <button class="btn-icon delete" onclick="eliminarArtefacto(<?= $a['id_artefacto'] ?>)"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© <?php echo date("Y"); ?> SANDBOX. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script>
        const form = document.getElementById('formArtefacto');

        form.addEventListener('submit', e => {
            e.preventDefault();
            const data = new FormData(form);
            const url = data.get('id_artefacto') ? '?url=artefactos/update' : '?url=artefactos/create';
            fetch(url, {
                    method: 'POST',
                    body: data
                })
                .then(r => r.json())
                .then(j => {
                    if (j.status === 'ok') location.reload();
                    else alert("Error: " + (j.error || "No se pudo completar la acción"));
                });
        });

        function editarArtefacto(id, nombre, descripcion, imagen, sala, tipo, autor, fecha) {
            form.id_artefacto.value = id;
            form.nombre.value = nombre;
            form.descripcion.value = descripcion;
            form.id_sala.value = sala;
            form.id_tipo.value = tipo;
            form.id_autor.value = autor;
            form.fecha_creacion.value = fecha;

            // Mostrar imagen previa
            const imgPreview = document.getElementById('previewImagen');
            imgPreview.src = imagen;
            imgPreview.style.display = 'block';

            // Eliminar required del input de imagen
            document.getElementById('imagen').required = false;

            // Desplazarse automáticamente al formulario
            form.scrollIntoView({
                behavior: 'smooth'
            });
        }

        function eliminarArtefacto(id) {
            if (confirm("¿Eliminar este artefacto?")) {
                fetch('?url=artefactos/delete', {
                        method: 'POST',
                        body: new URLSearchParams({
                            id_artefacto: id
                        })
                    })
                    .then(r => r.json())
                    .then(j => {
                        if (j.status === 'ok') location.reload();
                        else alert("Error al eliminar.");
                    });
            }
        }
    </script>
</body>

</html>