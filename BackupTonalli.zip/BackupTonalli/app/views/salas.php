<?php
if (!isset($_SESSION['admin_nombre'])) {
    header("Location: index.php?url=login");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Gestión de Salas - TonalliApp</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap y FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />

    <!-- Estilos -->
    <link rel="stylesheet" href="public/css/styles.css" />
</head>

<body>
    <!-- Header -->
    <header class="main-header d-flex align-items-center px-4 shadow-sm">
        <img src="public/img/logo.png" alt="Logo TonalliApp" class="logo">
        <h1 class="app-title">TonalliApp</h1>
    </header>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-4 col-lg-3 d-md-block bg-light sidebar border-end vh-100">
                <div class="position-sticky pt-3">
                    <h4 class="text-center py-3 text-primary">Menú</h4>
                    <ul class="nav flex-column px-3">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=dashboard"><i class="fas fa-home me-2"></i>Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=salas"><i class="fas fa-door-open me-2"></i>Salas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=artefactos"><i class="fas fa-landmark me-2"></i>Artefactos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=autores"><i class="fas fa-user-edit me-2"></i>Autores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=citas"><i class="fas fa-calendar-check me-2"></i>Citas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?url=usuarios"><i class="fas fa-users me-2"></i>Usuarios</a>
                        </li>
                        <li class="nav-item mt-3">
                            <a class="nav-link text-danger" href="index.php?url=login"><i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main -->
            <main class="col-md-8 ms-sm-auto col-lg-9 px-md-4 pt-4">
                <h2 class="tonalli-header mb-4">Gestión de Salas</h2>

                <form id="formSala" class="mb-4 row g-3">
                    <div class="col-md-5">
                        <input name="nombre" class="form-control" placeholder="Nombre de la sala" required />
                    </div>
                    <div class="col-md-5">
                        <input name="descripcion" class="form-control" placeholder="Descripción" required />
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn w-100">Guardar</button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th class="text-end">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($salas as $s): ?>
                                <tr>
                                    <td><?= $s['id_sala'] ?></td>
                                    <td><?= htmlspecialchars($s['nombre']) ?></td>
                                    <td><?= htmlspecialchars($s['descripcion']) ?></td>
                                    <td class="text-end">
                                        <button class="btn-icon edit" onclick="editarSala(<?= $s['id_sala'] ?>, '<?= htmlspecialchars($s['nombre']) ?>', '<?= htmlspecialchars($s['descripcion']) ?>')">
                                            <i class="fas fa-pen"></i>
                                        </button>
                                        <button class="btn-icon delete" onclick="eliminarSala(<?= $s['id_sala'] ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container text-center">
            <p class="mb-0">© <?php echo date("Y"); ?> SANDBOX. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- JS -->
    <script>
        const form = document.getElementById('formSala');
        let idEditando = null;

        form.addEventListener('submit', e => {
            e.preventDefault();
            const formData = new FormData(form);

            if (idEditando) {
                formData.append('id_sala', idEditando);
            }

            const url = idEditando ? '?url=salas/update' : '?url=salas/create';

            fetch(url, {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(j => {
                    if (j.status === 'ok') {
                        form.reset();
                        idEditando = null;
                        window.location.reload();
                    } else {
                        alert("Error: " + (j.error || 'No se pudo completar la acción'));
                    }
                });
        });

        function editarSala(id, nombre, descripcion) {
            form.nombre.value = nombre;
            form.descripcion.value = descripcion;
            idEditando = id;
        }

        function eliminarSala(id) {
            if (confirm("¿Estás seguro de que deseas eliminar esta sala?")) {
                fetch(`?url=salas/delete`, {
                        method: 'POST',
                        body: new URLSearchParams({
                            id_sala: id
                        })
                    })
                    .then(r => r.json())
                    .then(j => {
                        if (j.status === 'ok') {
                            window.location.reload();
                        } else {
                            alert("Error al eliminar sala");
                        }
                    });
            }
        }
    </script>
</body>

</html>