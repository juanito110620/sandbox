<?php   
class LoginController
{
    public function index()
    {
        require_once __DIR__ . '/../views/login.php';
    }

    public function authenticate()
    {
        require_once __DIR__ . '/../models/Admin.php';

        $correo = $_POST['usuario'] ?? '';
        $contrasena = $_POST['contrasena'] ?? '';

        $adminModel = new Admin();
        $admin = $adminModel->obtenerPorCorreo($correo);

        if ($admin && password_verify($contrasena, $admin['contrasena'])) {
            $_SESSION['admin_id'] = $admin['id_admin'];
            $_SESSION['admin_nombre'] = $admin['nombre'];
            header('Location: index.php?url=dashboard');
            exit();
        } else {
            $error = "Credenciales inválidas.";
            require_once __DIR__ . '/../views/login.php';
        }
    }
}