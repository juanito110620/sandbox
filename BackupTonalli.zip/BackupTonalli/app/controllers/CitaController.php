<?php
require_once __DIR__ . '/../models/Cita.php';

class CitaController
{
    private $model;

    public function __construct()
    {
        $this->model = new Cita();
    }

    public function index()
    {
        $busqueda = isset($_GET['busqueda']) ? trim($_GET['busqueda']) : '';
        $citas = $this->model->getAll($busqueda);
        require __DIR__ . '/../views/citas.php';
    }

    public function delete()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_cita'])) {
            $this->model->delete($_POST['id_cita']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'ID inválido o método incorrecto']);
    }
}
