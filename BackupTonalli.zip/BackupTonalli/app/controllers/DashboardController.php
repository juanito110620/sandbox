<?php

class DashboardController {
    public function index() {
        $db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );

        if ($db->connect_error) die("Error de conexión: " . $db->connect_error);

        // Totales dinámicos
        $totalSalas = $db->query("SELECT COUNT(*) AS t FROM sala")->fetch_assoc()['t'];
        $totalArtefactos = $db->query("SELECT COUNT(*) AS t FROM artefacto")->fetch_assoc()['t'];
        $totalCitas = $db->query("SELECT COUNT(*) AS t FROM citas")->fetch_assoc()['t'];

        require __DIR__ . '/../views/dashboard.php';
    }
}