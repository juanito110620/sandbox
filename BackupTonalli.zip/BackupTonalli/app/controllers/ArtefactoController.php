<?php
require_once __DIR__ . '/../models/Artefacto.php';

class ArtefactoController
{
    private $model;

    public function __construct()
    {
        $this->model = new Artefacto();
    }

    public function index()
    {
        $artefactos = $this->model->getAll();
        $salas = $this->model->getSalas();
        $tipos = $this->model->getTipos();
        $autores = $this->model->getAutores();
        require __DIR__ . '/../views/artefactos.php';
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->create(
                $_POST['nombre'],
                $_POST['descripcion'],
                $_FILES['imagen'],
                $_POST['id_sala'],
                $_POST['id_tipo'],
                $_POST['id_autor'],
                $_POST['fecha_creacion']
            );
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function update()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->update(
                $_POST['id_artefacto'],
                $_POST['nombre'],
                $_POST['descripcion'],
                $_FILES['imagen'] ?? null,
                $_POST['id_sala'],
                $_POST['id_tipo'],
                $_POST['id_autor'],
                $_POST['fecha_creacion']
            );
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function delete()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_artefacto'])) {
            $this->model->delete($_POST['id_artefacto']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'ID inválido o método incorrecto']);
    }
}