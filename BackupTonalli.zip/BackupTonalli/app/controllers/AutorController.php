<?php
require_once __DIR__ . '/../models/Autor.php';

class AutorController
{
    private $model;

    public function __construct()
    {
        $this->model = new Autor();
    }

    public function index()
    {
        $autores = $this->model->getAll();
        require __DIR__ . '/../views/autores.php';
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->create($_POST['nombre'], $_POST['nacionalidad']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function update()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->update($_POST['id_autor'], $_POST['nombre'], $_POST['nacionalidad']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function delete()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->delete($_POST['id_autor']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }
}