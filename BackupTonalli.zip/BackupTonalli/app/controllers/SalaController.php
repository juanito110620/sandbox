<?php
require_once __DIR__ . '/../models/Sala.php';

class SalaController
{
    private $model;
    public function __construct()
    {
        $this->model = new Sala();
    }

    public function index()
    {
        $salas = $this->model->getAll();
        require __DIR__ . '/../views/salas.php';
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->create($_POST['nombre'], $_POST['descripcion']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function update()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->update($_POST['id_sala'], $_POST['nombre'], $_POST['descripcion']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }

    public function delete()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->delete($_POST['id_sala']);
            echo json_encode(['status' => 'ok']);
            return;
        }
        echo json_encode(['error' => 'Método no permitido']);
    }
}