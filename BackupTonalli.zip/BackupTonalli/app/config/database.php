<?php
$host = 'sql104.infinityfree.com';
$user = 'if0_39575057';
$pass = 's4ndb0x2025';
$db = 'if0_39575057_museo_chimaltonalli';

$conexion = new mysqli($host, $user, $pass, $db);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>