<?php
require_once __DIR__ . '/../../vendor/autoload.php';

\Cloudinary\Configuration\Configuration::instance([
    'cloud' => [
        'cloud_name' => 'dgs3vnnrv',
        'api_key'    => '161535792114432',
        'api_secret' => 'xjhhaZeMRRsPVJRgwEBmKJNlei0'
    ],
    'url' => [
        'secure' => true
    ]
]);