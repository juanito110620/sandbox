<?php
$url = $_GET['url'] ?? 'login';

switch ($url) {
    case 'login':
        require_once __DIR__ . '/../controllers/LoginController.php';
        $controller = new LoginController();
        $controller->index();
        break;

    case 'authenticate':
        require_once __DIR__ . '/../controllers/LoginController.php';
        $controller = new LoginController();
        $controller->authenticate();
        break;

    case 'dashboard':
        require_once __DIR__ . '/../controllers/DashboardController.php';
        $controller = new DashboardController();
        $controller->index();
        break;

    //Salas
    case 'salas':
        require_once __DIR__ . '/../controllers/SalaController.php';
        $controller = new SalaController();
        $controller->index();
        break;

    case 'salas/create':
        require_once __DIR__ . '/../controllers/SalaController.php';
        $controller = new SalaController();
        $controller->create();
        break;

    case 'salas/update':
        require_once __DIR__ . '/../controllers/SalaController.php';
        $controller = new SalaController();
        $controller->update();
        break;

    case 'salas/delete':
        require_once __DIR__ . '/../controllers/SalaController.php';
        $controller = new SalaController();
        $controller->delete();
        break;

    //Artefactos
    case 'artefactos':
        require_once __DIR__ . '/../controllers/ArtefactoController.php';
        $controller = new ArtefactoController();
        $controller->index();
        break;

    case 'artefactos/create':
        require_once __DIR__ . '/../controllers/ArtefactoController.php';
        $controller = new ArtefactoController();
        $controller->create();
        break;

    case 'artefactos/update':
        require_once __DIR__ . '/../controllers/ArtefactoController.php';
        $controller = new ArtefactoController();
        $controller->update();
        break;

    case 'artefactos/delete':
        require_once __DIR__ . '/../controllers/ArtefactoController.php';
        $controller = new ArtefactoController();
        $controller->delete();
        break;

    // Autores
    case 'autores':
        require_once __DIR__ . '/../controllers/AutorController.php';
        $controller = new AutorController();
        $controller->index();
        break;

    case 'autores/create':
        require_once __DIR__ . '/../controllers/AutorController.php';
        $controller = new AutorController();
        $controller->create();
        break;

    case 'autores/update':
        require_once __DIR__ . '/../controllers/AutorController.php';
        $controller = new AutorController();
        $controller->update();
        break;

    case 'autores/delete':
        require_once __DIR__ . '/../controllers/AutorController.php';
        $controller = new AutorController();
        $controller->delete();
        break;

    // Citas
    case 'citas':
        require_once __DIR__ . '/../controllers/CitaController.php';
        $controller = new CitaController();
        $controller->index();
        break;

    case 'citas/delete':
        require_once __DIR__ . '/../controllers/CitaController.php';
        $controller = new CitaController();
        $controller->delete();
        break;

    // Usuarios
    case 'usuarios':
        require_once __DIR__ . '/../controllers/UsuarioController.php';
        $controller = new UsuarioController();
        $controller->index();
        break;

    case 'usuarios/delete':
        require_once __DIR__ . '/../controllers/UsuarioController.php';
        $controller = new UsuarioController();
        $controller->delete();
        break;

    default:
        echo "Página no encontrada.";
}