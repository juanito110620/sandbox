<?php
class Sala
{
    private $db;
public function __construct()
    {
        $this->db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );
        if ($this->db->connect_error) {
            die('DB error: ' . $this->db->connect_error);
        }

        $this->db->set_charset("utf8");
    }

    public function getAll(): array
    {
        return $this->db->query("SELECT * FROM sala")->fetch_all(MYSQLI_ASSOC);
    }

    public function create(string $nombre, string $desc)
    {
        $stmt = $this->db->prepare("INSERT INTO sala (nombre, descripcion) VALUES(?, ?)");
        $stmt->bind_param("ss", $nombre, $desc);
        $stmt->execute();
    }

    public function update(int $id, string $nombre, string $desc)
    {
        $stmt = $this->db->prepare("UPDATE sala SET nombre = ?, descripcion = ? WHERE id_sala = ?");
        $stmt->bind_param("ssi", $nombre, $desc, $id);
        $stmt->execute();
    }

    public function delete(int $id)
    {
        $stmt = $this->db->prepare("DELETE FROM sala WHERE id_sala = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}