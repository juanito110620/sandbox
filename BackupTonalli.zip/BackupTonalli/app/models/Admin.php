<?php
class Admin
{
    private $db;

    public function __construct()
    {
        $this->db = new mysqli('sql104.infinityfree.com', 'if0_39575057', 's4ndb0x2025', 'if0_39575057_museo_chimaltonalli');
        if ($this->db->connect_error) {
            die('Error de conexión: ' . $this->db->connect_error);
        }
    }

    public function obtenerPorCorreo($correo)
    {
        $stmt = $this->db->prepare("SELECT * FROM admins WHERE correo = ?");
        $stmt->bind_param('s', $correo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        return $resultado->fetch_assoc();
    }
}