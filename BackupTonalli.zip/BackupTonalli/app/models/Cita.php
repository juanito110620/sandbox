<?php
class Cita
{
    private $db;

    public function __construct()
    {
        $this->db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );
        if ($this->db->connect_error) {
            die('DB error: ' . $this->db->connect_error);
        }

        $this->db->set_charset("utf8");
    }

    // Obtener todas o filtrar por usuario
    public function getAll($busqueda = null)
    {
        $sql = "SELECT c.*, u.nombre AS nombre_usuario
            FROM citas c
            JOIN usuarios u ON c.id_usuario = u.id_usuario";

        if ($busqueda !== null && $busqueda !== '') {
            $sql .= " WHERE c.id_usuario = ? OR c.nombre_visitante LIKE ?";
            $stmt = $this->db->prepare($sql);
            $like = "%$busqueda%";
            // Si es numérico, buscará también por ID. Si no, igual se manda.
            $id = is_numeric($busqueda) ? intval($busqueda) : 0;
            $stmt->bind_param("is", $id, $like);
            $stmt->execute();
            return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        } else {
            $result = $this->db->query($sql);
            return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        }
    }

    public function delete($id_cita)
    {
        $stmt = $this->db->prepare("DELETE FROM citas WHERE id_cita = ?");
        $stmt->bind_param("i", $id_cita);
        $stmt->execute();
    }
}
