<?php
class Usuario
{
    private $db;

public function __construct()
    {
        $this->db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );
        if ($this->db->connect_error) {
            die('DB error: ' . $this->db->connect_error);
        }

        $this->db->set_charset("utf8");
    }

    public function getAll($busqueda = null)
    {
        $sql = "SELECT * FROM usuarios";
        if ($busqueda !== null && $busqueda !== '') {
            $sql .= " WHERE id_usuario = ? OR nombre LIKE ?";
            $stmt = $this->db->prepare($sql);
            $like = "%$busqueda%";
            $id = is_numeric($busqueda) ? intval($busqueda) : 0;
            $stmt->bind_param("is", $id, $like);
            $stmt->execute();
            return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        } else {
            $result = $this->db->query($sql);
            return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        }
    }

    public function delete($id_usuario)
    {
        $stmt = $this->db->prepare("DELETE FROM usuarios WHERE id_usuario = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
    }
}