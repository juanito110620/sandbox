<?php
class Autor
{
    private $db;

    public function __construct()
    {
        $this->db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );
        if ($this->db->connect_error) {
            die('DB error: ' . $this->db->connect_error);
        }

        $this->db->set_charset("utf8");
    }
    public function getAll(): array
    {
        return $this->db->query("SELECT * FROM autor")->fetch_all(MYSQLI_ASSOC);
    }

    public function create(string $nombre, string $nacionalidad)
    {
        $stmt = $this->db->prepare("INSERT INTO autor (nombre, nacionalidad) VALUES (?, ?)");
        $stmt->bind_param("ss", $nombre, $nacionalidad);
        $stmt->execute();
    }

    public function update(int $id, string $nombre, string $nacionalidad)
    {
        $stmt = $this->db->prepare("UPDATE autor SET nombre = ?, nacionalidad = ? WHERE id_autor = ?");
        $stmt->bind_param("ssi", $nombre, $nacionalidad, $id);
        $stmt->execute();
    }

    public function delete(int $id)
    {
        $stmt = $this->db->prepare("DELETE FROM autor WHERE id_autor = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}
