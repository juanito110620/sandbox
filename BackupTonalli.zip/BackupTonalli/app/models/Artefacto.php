<?php

use Cloudinary\Api\Upload\UploadApi;

class Artefacto
{
    private $db;

    public function __construct()
    {
        $this->db = new mysqli(
            'sql104.infinityfree.com',
            'if0_39575057',
            's4ndb0x2025',
            'if0_39575057_museo_chimaltonalli'
        );
        if ($this->db->connect_error) {
            die('DB error: ' . $this->db->connect_error);
        }

        $this->db->set_charset("utf8");
    }

    public function getAll()
    {
        $query = "SELECT a.*, s.nombre AS nombre_sala, t.nombre AS nombre_tipo, au.nombre AS nombre_autor 
              FROM artefacto a
              JOIN sala s ON a.id_sala = s.id_sala
              JOIN tipo_artefacto t ON a.id_tipo = t.id_tipo
              JOIN autor au ON a.id_autor = au.id_autor
              ORDER BY FIELD(s.nombre,
                  'Canteros Actual y Zona Arqueológica',
                  'Antigüedades y Artefactos',
                  'Fósiles',
                  'Cultura Material',
                  'Fauna y Armas',
                  'Vestimenta y Cultura',
                  'Pinturas Gastronómicas',
                  'Exposiciones Temporales'
              ), a.id_artefacto ASC";

        $result = $this->db->query($query);
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function getSalas()
    {
        return $this->db->query("SELECT id_sala, nombre FROM sala")->fetch_all(MYSQLI_ASSOC);
    }

    public function getTipos()
    {
        return $this->db->query("SELECT id_tipo, nombre FROM tipo_artefacto")->fetch_all(MYSQLI_ASSOC);
    }

    public function getAutores()
    {
        return $this->db->query("SELECT id_autor, nombre FROM autor")->fetch_all(MYSQLI_ASSOC);
    }

    public function create($nombre, $descripcion, $imagenFile, $id_sala, $id_tipo, $id_autor, $fecha_creacion)
    {
        require_once __DIR__ . '/../config/cloudinary_config.php';
        require_once __DIR__ . '/../../vendor/autoload.php';

        $uploadResult = (new UploadApi())->upload($imagenFile['tmp_name'], ['folder' => 'tonalli_artefactos']);
        $imagenFinal = $uploadResult['secure_url'];

        $stmt = $this->db->prepare("INSERT INTO artefacto (nombre, descripcion, imagen, id_sala, id_tipo, id_autor, fecha_creacion) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssiiis", $nombre, $descripcion, $imagenFinal, $id_sala, $id_tipo, $id_autor, $fecha_creacion);
        $stmt->execute();
    }

    public function update($id, $nombre, $descripcion, $imagenFile, $id_sala, $id_tipo, $id_autor, $fecha_creacion)
    {
        require_once __DIR__ . '/../config/cloudinary_config.php';
        require_once __DIR__ . '/../../vendor/autoload.php';

        $imagenFinal = null;
        if ($imagenFile && $imagenFile['tmp_name']) {
            $uploadResult = (new UploadApi())->upload($imagenFile['tmp_name'], ['folder' => 'tonalli_artefactos']);
            $imagenFinal = $uploadResult['secure_url'];
        }

        if ($imagenFinal) {
            $stmt = $this->db->prepare("UPDATE artefacto SET nombre=?, descripcion=?, imagen=?, id_sala=?, id_tipo=?, id_autor=?, fecha_creacion=? WHERE id_artefacto=?");
            $stmt->bind_param("sssiiisi", $nombre, $descripcion, $imagenFinal, $id_sala, $id_tipo, $id_autor, $fecha_creacion, $id);
        } else {
            $stmt = $this->db->prepare("UPDATE artefacto SET nombre=?, descripcion=?, id_sala=?, id_tipo=?, id_autor=?, fecha_creacion=? WHERE id_artefacto=?");
            $stmt->bind_param("ssiiisi", $nombre, $descripcion, $id_sala, $id_tipo, $id_autor, $fecha_creacion, $id);
        }

        $stmt->execute();
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM artefacto WHERE id_artefacto = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}
